﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text.Json;
using GraphQL.Client.Http;
using GraphQL.Client.Serializer.Newtonsoft;
using GraphQL;
using System.Threading.Tasks;
using System.IO;
using System.Net;
using System.Text;
using GraphQL.Client.Abstractions;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Response.Write("Hello");

        RegisterAsyncTask(new PageAsyncTask(PageLoadAsync));

    }
    public async Task PageLoadAsync()
    {
        txtResult.Text = await InvokeGraphQLAPI();
    }

    public static async Task<string> InvokeGraphQLAPI()
    {
        try
        {
            string sURL = "https://spacex-production.up.railway.app/";

            var graphQLClient = new GraphQLHttpClient(sURL,
                                                      new NewtonsoftJsonSerializer());

            var heroRequest = new GraphQLRequest
            {
                Query = @"
                        query ExampleQuery {  company {    ceo  }
                                         }"
            };

            var graphQLResponse = await graphQLClient.SendQueryAsync<data>(heroRequest);
            Console.WriteLine("raw response:");
            Console.WriteLine(JsonSerializer.Serialize(graphQLResponse, new JsonSerializerOptions { WriteIndented = true }));

            Console.WriteLine();
            Console.WriteLine($"Name: {graphQLResponse.Data.company}");
            return graphQLResponse.Data.company.ceo;

        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.ToString());
        }
        return "";


    }

    public class data
    {
        public company company { get; set; }
    }


    public class company
    {
        public string ceo { get; set; }
    }


}